Operating Systems - Lab 1

Students:
  Stefan Evanghelides - s2895323
  Matthew Watkins - s2864800

Contains:
  execute
  ring
  duplicates

Each folder contains a Makefile for its respective program. The files are heavily commented for clarity purposes.

For duplicates, we added a test folder in which we copy-pasted the Makefile. We also made a copy of Makefile in the main folder and renamed it Makefile2. Therefore, the expected output should be the following 3 pairs:
  Makefile - Makefile2
  Makefile - test/Makefile
  Makefile2 - test/Makefile
